﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using project_in_sha_Allah.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace project_in_sha_Allah.Controllers
{
    public class Employee : Controller
    {
        private readonly Mycontext _Db;
        public Employee(Mycontext Db)
        {
            _Db = Db;
        }
        public IActionResult EmployeeList()
        {
                
                  var EmpList = _Db.login.ToList() ;           
                  return View(EmpList);
           
        }
        public IActionResult Index()
        {      
            return View();
        }
        [HttpPost]
        //public IActionResult Registerthroughstrongbinding(Login abc)
        //{
            
        //    _Db.login.Add(abc);
        //    _Db.SaveChanges();
        //    return Content("congrats,u are in.../n now go log in ");

        //}
       [HttpPost]
        public IActionResult Register1(string Name = "a", string Pass = "b",string email = "e")
        {
            Login abc1 = new Login();
            abc1.name = Name;
           abc1.email = email;
            abc1.pass = Pass;
                _Db.login.Add(abc1);
                _Db.SaveChanges();

            return View();
            //return Content("congrats,u are in.../n now go log in ");

        }
        public async Task<IActionResult> Edit(int? id)
        {
            var EmpList =await  _Db.login.FirstOrDefaultAsync(e => e.id == id);

            return View(EmpList);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Login Emp)
        {
            if (!ModelState.IsValid)
                return View(Emp);

            _Db.login.Update(Emp);
            await _Db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

       public async Task<IActionResult> Delete(int? id)
        {
            var EmpList = await _Db.login.FirstOrDefaultAsync(e => e.id == id);
            _Db.login.Remove(EmpList);
            await _Db.SaveChangesAsync();

            return RedirectToAction("Index");
        }


        [HttpGet]
        public IActionResult Verify(string Name = "a", string Pass = "b")
        {
            var user = _Db.login.Where(x => x.name == Name && x.pass == Pass).Count();
            if (user > 0)
            {
               var EmpList = _Db.login.ToList() ;           
                  return View(EmpList);
                //return View("EmployeeList");
            }
            else
            {
                  return Content("wrong credentials");
            }       
        }
    }
}
